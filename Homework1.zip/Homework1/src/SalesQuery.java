
public class SalesQuery {

}
