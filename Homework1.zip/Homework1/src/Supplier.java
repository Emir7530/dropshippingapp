
public class Supplier {
	private Product product;

}
