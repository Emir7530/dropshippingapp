
public class SalesManagement {
	private Sales sales;
	

}
